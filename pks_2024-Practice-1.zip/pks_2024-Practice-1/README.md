# Практика 1 - Игошев М. Л. ЭФБО-02-22

![screenshot](https://github.com/user-attachments/assets/2a398b82-5191-4488-a331-5e72d4190976)
